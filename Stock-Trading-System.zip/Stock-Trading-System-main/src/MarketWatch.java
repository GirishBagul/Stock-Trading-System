import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.json.JSONException;

import java.io.FileNotFoundException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;

public class MarketWatch extends JFrame implements ActionListener {

    JButton button1,popStockButton,back,marketIndicesButton;
    JTextField stockname;
    public void displayMessage(String message) {
		JFrame f=new JFrame();
		JOptionPane.showMessageDialog(f,message);
	}
    public MarketWatch(){

        JLabel stocknameLabel = new JLabel("STOCK NAME : ");
        stocknameLabel.setBounds(50,150,230,35);
        stocknameLabel.setFont(new Font("Georgia",Font.BOLD,20));
        stocknameLabel.setForeground(Color.BLACK);

        stockname = new JTextField();
        stockname.setBounds(240,150,200,35);
        stockname.setPreferredSize(new Dimension(120,25));

        button1 = new JButton("GET DATA");
        button1.setBounds(250,210,120,35);
        button1.addActionListener(this);
        button1.setFont(new Font("sans-serif",Font.PLAIN,15));
        button1.setForeground(Color.BLACK);
        button1.setFocusable(true);

        popStockButton = new JButton("POPULAR STOCKS");
        popStockButton.setBounds(200,300,200,50);
        popStockButton.addActionListener(this);
        popStockButton.setFont(new Font("sans-serif",Font.PLAIN,15));
        popStockButton.setForeground(Color.BLACK);
        popStockButton.setFocusable(false);

        back=new JButton("<");
        back.setBounds(570,10,20,20);
        back.addActionListener(this);






        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600,500);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(133, 205, 202));
        this.setVisible(true);

        this.add(button1);
        this.add(stocknameLabel);
        this.add(stockname);
        this.add(popStockButton);
        this.add(back);



    }
    public void forEachStock(Stock s) throws JSONException {

        LocalDate date = LocalDate.now().minusDays(1);
        String d = date.toString();
        String day = date.getDayOfWeek().toString();
        String latestDay;
        String earlierDay;
        if (day.equals("SUNDAY")) {
            latestDay = date.minusDays(1).with(TemporalAdjusters.previous(DayOfWeek.FRIDAY)).toString();
            earlierDay = date.minusDays(8).with(TemporalAdjusters.previous(DayOfWeek.FRIDAY)).toString();
        } else if (day.equals("SATURDAY")) {
            latestDay = date.with(TemporalAdjusters.previous(DayOfWeek.FRIDAY)).toString();
            earlierDay = date.minusDays(6).with(TemporalAdjusters.previous(DayOfWeek.FRIDAY)).toString();
        } else {
            latestDay = date.with(TemporalAdjusters.previous(DayOfWeek.FRIDAY)).toString();
            earlierDay = date.minusDays(7).with(TemporalAdjusters.previous(DayOfWeek.FRIDAY)).toString();
        }

        System.out.println(String.format("%s | %.3f | %s", s.getSymbol(), s.getClosePrice(), s.StockTrend(latestDay, earlierDay)));

    }
    public void popularTechStocks() throws JSONException {

        System.out.println("*".repeat(50));
        System.out.println("Stock : Current price : Performance");
        Stock[] StockArr = {new Stock("GOOGL"), new Stock("TXN"),new Stock("AAPL") };
        for(Stock A : StockArr){
            this.forEachStock(A);
        }
        System.out.println("*".repeat(50));

    }
    public void marketIndices(){
    	/*String s="";
    	s+="\t\tMarket Indices";
    	s+="\n"+"-".repeat(50);
    	s+="\n"+"NYSE Composite index: $16,868.11";
    	s+="\n"+"Dow Jones Industrial Average: $35,515.38";
    	s+="\n"+"S&P 500 Index: $14,822.55";
    	s+="\n"+"Russell 2000 Index: $2,223.11";
    	s+="\n"+"Global Dow Realtime USD: $4,097.02";
    	s+="\n"+"Dow Jones U.S. Total Stock Market Index: $46,820.65";
    	s+="\n"+"NASDAQ 100 Index (NASDAQ Calculation): $15,136.68";
    	s+="\n"+"NYSE Composite Index: $16,868.11";
    	s+="\n"+"-".repeat(50);
    	System.out.println(s);
    	displayMessage(s);

    	 */
//        System.out.println("\t\tMarket Indices \n"+"-".repeat(50));
//        System.out.println("NYSE Composite index: $16,868.11");
//        System.out.println("Dow Jones Industrial Average: $35,515.38");
//        System.out.println("S&P 500 Index: $14,822.55");
//        System.out.println("Russell 2000 Index: $2,223.11");
//        System.out.println("Global Dow Realtime USD: $4,097.02");
//        System.out.println("Dow Jones U.S. Total Stock Market Index: $46,820.65");
//        System.out.println("NASDAQ 100 Index (NASDAQ Calculation): $15,136.68");
//        System.out.println("NYSE Composite Index: $16,868.11"+"-".repeat(50));
    }
    public void completeStockData(String symbol) throws JSONException {
        System.out.println("*".repeat(50));
        Stock stock = new Stock(symbol);
        forEachStock(stock);
        System.out.println("*".repeat(50));
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==button1){
            try {
                System.out.println("*".repeat(50));
                System.out.println("Stock : Current price : Performance");
                forEachStock(new Stock(stockname.getText().toString()));
                System.out.println("*".repeat(50));
            } catch (JSONException jsonException) {
                jsonException.printStackTrace();
            }
            displayMessage("Please check the console for the details");
        }
        if(e.getSource()==marketIndicesButton){
            this.marketIndices();
        }
        if(e.getSource()==popStockButton){
            try {
                this.popularTechStocks();
            } catch (JSONException jsonException) {
                jsonException.printStackTrace();
            }
            displayMessage("Please check the console for the details");
        }

        if(e.getSource()==back){
                OnLogin log = new OnLogin("");
        }
    }

    public static void main(String[] args) throws JSONException {
        MarketWatch m = new MarketWatch();
    }
}