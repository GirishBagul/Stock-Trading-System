import java.io.FileNotFoundException;
import java.io.IOException;
import org.json.JSONException;

public class Main{

	public static void main(String[] args) throws FileNotFoundException, JSONException {
		FirstPageGUI gui = new FirstPageGUI();
	}

}
